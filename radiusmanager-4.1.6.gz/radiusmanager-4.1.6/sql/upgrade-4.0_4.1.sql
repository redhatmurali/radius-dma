ALTER TABLE `radpostauth` ADD `nasipaddress` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `radpostauth` ADD INDEX ( `username` ) ;
ALTER TABLE `radpostauth` ADD INDEX ( `authdate` ) ;
ALTER TABLE `radpostauth` ADD INDEX ( `nasipaddress` ) ;

CREATE TABLE `rm_colsetlistusers` (
  `managername` varchar(64) NOT NULL,
  `colname` varchar(32) NOT NULL,
  KEY `managername` (`managername`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'username'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'srvname'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'expiry'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'availdl'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'availul'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'availtotal'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'availtime'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'cpeip'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'cmip'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'cmmac'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'firstname'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'lastname'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'company'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'address'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'city'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'zip'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'country'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'state'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'email'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'comment'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'registered'
FROM rm_managers;
INSERT INTO rm_colsetlistusers ( managername, colname ) 
SELECT managername, 'lastlogoff'
FROM rm_managers;

CREATE TABLE `rm_colsetlistradius` (
  `managername` varchar(64) NOT NULL,
  `colname` varchar(32) NOT NULL,
  KEY `managername` (`managername`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'comment'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'email'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'state'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'country'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'zip'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'city'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'address'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'company'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'lastname'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'firstname'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'group'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'nas'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'ccq'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'snr'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'signal'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'apname'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'mac'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'ip'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'upload'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'download'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'onlinetime'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'starttime'
FROM rm_managers;
INSERT INTO rm_colsetlistradius ( managername, colname ) 
SELECT managername, 'username'
FROM rm_managers;

CREATE TABLE `rm_colsetlistdocsis` (
  `managername` varchar(64) NOT NULL,
  `colname` varchar(32) NOT NULL,
  KEY `managername` (`managername`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'firstname'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'lastname'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'company'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'address'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'city'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'zip'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'country'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'state'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'email'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'comment'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'groupname'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'upstreamname'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'cmtsname'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'pingtime'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'rxpwr'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'txpwr'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'snrus'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'snrds'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'username'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'cmmac'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'cmip'
FROM rm_managers;
INSERT INTO rm_colsetlistdocsis ( managername, colname ) 
SELECT managername, 'cpeip'
FROM rm_managers;

ALTER TABLE `rm_invoices` ADD `capdl` TINYINT( 1 ) NOT NULL AFTER `expiration` ,
ADD `capul` TINYINT( 1 ) NOT NULL AFTER `capdl` ,
ADD `captotal` TINYINT( 1 ) NOT NULL AFTER `capul` ,
ADD `captime` TINYINT( 1 ) NOT NULL AFTER `captotal` ,
ADD `capdate` TINYINT( 1 ) NOT NULL AFTER `captime` ;

ALTER TABLE `rm_managers` ADD `lang` VARCHAR( 30 ) NOT NULL ;

CREATE TABLE `rm_newusers` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(64) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zip` varchar(8) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `vatid` varchar(40) NOT NULL,
  `srvid` int(11) NOT NULL,
  `actcode` varchar(10) NOT NULL,
  `actcount` int(11) NOT NULL,
  `lang` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `rm_phpsess` (
  `managername` varchar(64) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `sessid` varchar(64) NOT NULL,
  `lastact` datetime NOT NULL,
  `closed` tinyint(1) NOT NULL,
  KEY `managername` (`managername`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `rm_services` ADD `descr` VARCHAR( 255 ) NOT NULL AFTER `srvname` ;
ALTER TABLE `rm_services` CHANGE `cmcfg` `cmcfg` VARCHAR( 10240 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_services` ADD `disnextsrvid` INT NOT NULL AFTER `dailynextsrvid` ;
UPDATE `rm_services` SET disnextsrvid = -1 ;

ALTER TABLE `rm_settings` ADD `disableexpcont` TINYINT( 1 ) NOT NULL AFTER `disablenotpaid` ;
ALTER TABLE `rm_settings` DROP `lang` ;
ALTER TABLE `rm_settings` ADD `newnasallsrv` TINYINT( 1 ) NOT NULL AFTER `resetctr` ,
ADD `newmanallsrv` TINYINT( 1 ) NOT NULL AFTER `newnasallsrv` ;
ALTER TABLE `rm_settings` ADD `smsexpiry` TINYINT( 1 ) NOT NULL AFTER `smswelcome` ;
ALTER TABLE `rm_settings` ADD `pm_payfast` TINYINT( 1 ) NOT NULL AFTER `pm_2co` ;
ALTER TABLE `rm_settings` CHANGE `pm_netcash` `pm_sagepay` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `selfreg_endupemail` TINYINT( 1 ) NOT NULL AFTER `selfreg_verify` ,
ADD `selfreg_endupmobile` TINYINT( 1 ) NOT NULL AFTER `selfreg_endupemail` ;
ALTER TABLE `rm_settings` ADD `ias_verify` TINYINT( 1 ) NOT NULL AFTER `ias_mobile` ,
ADD `ias_endupemail` TINYINT( 1 ) NOT NULL AFTER `ias_verify` ,
ADD `ias_endupmobile` TINYINT( 1 ) NOT NULL AFTER `ias_endupemail` ;
ALTER TABLE `rm_settings` CHANGE `selfreg_verify` `selfreg_mobactsms` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `selfreg_nameactemail` TINYINT( 1 ) NOT NULL AFTER `selfreg_mobactsms` ,
ADD `selfreg_nameactsms` TINYINT( 1 ) NOT NULL AFTER `selfreg_nameactemail` ;
ALTER TABLE `rm_settings` ADD `simuseselfreg` INT NOT NULL ;
UPDATE `rm_settings` SET simuseselfreg =1 ;

ALTER TABLE `rm_users` ADD `alertemail` TINYINT( 1 ) NOT NULL AFTER `pswactsmsnum` ,
ADD `alertsms` TINYINT( 1 ) NOT NULL AFTER `alertemail` ;
ALTER TABLE `rm_users` ADD `lang` VARCHAR( 30 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `email` `email` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` ADD `contractvalid` DATE NOT NULL AFTER `contractid` ;
ALTER TABLE `rm_users` ADD `lastlogoff` DATETIME NULL ;
ALTER TABLE `rm_users` ADD INDEX ( `contractvalid` ) ;
ALTER TABLE `rm_users` ADD INDEX ( `lastlogoff` ) ;
UPDATE rm_users SET alertemail =1;
UPDATE rm_users SET alertsms =1;

DROP TABLE IF EXISTS `rm_onlinecm`;
CREATE TABLE `rm_onlinecm` (
  `username` varchar(64) NOT NULL default '',
  `maccm` varchar(17) default NULL,
  `enableuser` tinyint(1) default NULL,
  `staticipcm` varchar(15) default NULL,
  `maccpe` varchar(17) default NULL,
  `ipcpe` varchar(15) default NULL,
  `ipmodecpe` tinyint(1) default NULL,
  `cmtsid` int(11) default NULL,
  `groupid` int(11) default NULL,
  `groupname` varchar(50) default NULL,
  `snrds` decimal(11,1) default NULL,
  `snrus` decimal(11,1) default NULL,
  `txpwr` decimal(11,1) default NULL,
  `rxpwr` decimal(11,1) default NULL,
  `pingtime` decimal(11,1) default NULL,
  `upstreamname` varchar(50) default NULL,
  `ifidx` int(11) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`username`),
  KEY `maccm` (`maccm`),
  KEY `staticipcm` (`staticipcm`),
  KEY `ipcpe` (`ipcpe`),
  KEY `groupname` (`groupname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `rm_wlan`;
CREATE TABLE `rm_wlan` (
  `maccpe` varchar(17) default NULL,
  `signal` smallint(6) default NULL,
  `ccq` smallint(6) default NULL,
  `snr` smallint(6) default NULL,
  `apip` varchar(15) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  KEY `maccpe` (`maccpe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

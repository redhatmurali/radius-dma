# modify table 'mt_users'

ALTER TABLE `mt_users` ADD `maconlyauth` TINYINT( 1 ) ;

ALTER TABLE `tabidx` ADD PRIMARY KEY ( `date` ) ;

ALTER TABLE `radacct` ADD `_AcctTime` DATETIME NOT NULL ;
ALTER TABLE `mt_payments` CHANGE `bytesdown` `bytesdown` BIGINT( 20 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_payments` CHANGE `bytesup` `bytesup` BIGINT( 20 ) DEFAULT '0' NOT NULL;

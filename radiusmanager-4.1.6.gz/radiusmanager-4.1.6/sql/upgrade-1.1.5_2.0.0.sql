ALTER TABLE `mt_managers` CHANGE `username` `username` VARCHAR( 16 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `password` `password` VARCHAR( 16 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `realname` `realname` VARCHAR( 30 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL;
ALTER TABLE `mt_managers` CHANGE `comment` `comment` VARCHAR( 50 ) NOT NULL;

ALTER TABLE `mt_payments` CHANGE `manager` `manager` VARCHAR( 20 ) NOT NULL;
ALTER TABLE `mt_payments` CHANGE `username` `username` VARCHAR( 20 ) NOT NULL;
ALTER TABLE `mt_payments` ADD `id` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;
ALTER TABLE `mt_payments` ADD INDEX ( `id` );
ALTER TABLE `mt_payments` CHANGE `payment` `price` DECIMAL( 20, 2 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_payments` DROP `megabytes`, DROP `recvlimit` , DROP `xmitlimit` ;
ALTER TABLE `mt_payments` ADD `bytesdown` INT( 11 ) DEFAULT '0' NOT NULL ,
ADD `bytesup` INT( 11 ) DEFAULT '0' NOT NULL ,
ADD `downlimit` BIGINT( 20 ) DEFAULT '0' NOT NULL ,
ADD `uplimit` BIGINT( 20 ) DEFAULT '0' NOT NULL ,
ADD `hours` INT( 11 ) DEFAULT '0' NOT NULL ,
ADD `uptimelimit` BIGINT( 20 ) DEFAULT '0' NOT NULL ,
ADD `days` INT( 6 ) DEFAULT '0' NOT NULL ,
ADD `expiration` DATE,
ADD `profname` VARCHAR( 25 ) NOT NULL ,
ADD `comment` VARCHAR( 70 ) NOT NULL;

ALTER TABLE `mt_payouts` CHANGE `payout` `payout` DECIMAL( 20, 2 ) DEFAULT '0' NOT NULL;

DROP TABLE IF EXISTS `mt_profiles`;
CREATE TABLE `mt_profiles` (
  `profid` int(3) NOT NULL default '0',
  `profname` varchar(25) NOT NULL,
  `downrate` int(11) NOT NULL default '0',
  `uprate` int(11) NOT NULL default '0',
  `limittraffic` tinyint(1) NOT NULL default '0',
  `limitexpiration` tinyint(1) NOT NULL default '0',
  `limituptime` tinyint(1) NOT NULL default '0',
  `poolname` varchar(25) NOT NULL
) TYPE=MyISAM;

ALTER TABLE `mt_payouts` CHANGE `manager` `manager` VARCHAR( 20 ) NOT NULL;

ALTER TABLE `mt_users` CHANGE `username` `username` VARCHAR( 20 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `password` `password` VARCHAR( 16 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `recvlimit` `uplimit` BIGINT( 20 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_users` CHANGE `xmitlimit` `downlimit` BIGINT( 20 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_users` CHANGE `mac` `mac` VARCHAR( 17 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `macid` `macid` INT( 11 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_users` ADD `nomacauth` TINYINT( 1 ) DEFAULT '0' NOT NULL;
ALTER TABLE `mt_users` CHANGE `realname` `realname` VARCHAR( 30 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `mt_users` ADD `mobile` VARCHAR( 15 ) NOT NULL AFTER `phone` ;
ALTER TABLE `mt_users` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL ;
ALTER TABLE `mt_users` CHANGE `comment` `comment` VARCHAR( 70 ) NOT NULL ;
ALTER TABLE `mt_users` DROP `datarate`;
ALTER TABLE `mt_users` DROP `nolimitrx` , DROP `nolimittx` ;
ALTER TABLE `mt_users` ADD `expiration` DATE,
ADD `uptimelimit` BIGINT( 20 ) DEFAULT '0' NOT NULL ,
ADD `profid` TINYINT( 2 ) DEFAULT '0' NOT NULL ;
ALTER TABLE `mt_users` ADD `enableuser` TINYINT( 1 ) DEFAULT '1' NOT NULL AFTER `password`;

ALTER TABLE `radacct` CHANGE `acctsessionid` `acctsessionid` VARCHAR( 64 ) NOT NULL default '' ;
ALTER TABLE `radacct` ADD `groupname` VARCHAR( 64 ) NOT NULL  default '' AFTER `username`;
ALTER TABLE `radacct` CHANGE `acctstarttime` `acctstarttime` DATETIME NULL ;
ALTER TABLE `radacct` CHANGE `acctstoptime` `acctstoptime` DATETIME NULL ;
ALTER TABLE `radacct` CHANGE `_AcctTime` `_AcctTime` DATETIME NULL ;
ALTER TABLE `radacct` CHANGE `_SrvId` `_SrvId` INT( 11 ) NULL ;
ALTER TABLE `radacct` ADD INDEX ( `acctsessiontime` ) ;

ALTER TABLE `radcheck` CHANGE `attribute` `attribute` VARCHAR( 64 ) NOT NULL default '' ;
UPDATE radcheck SET attribute = 'Cleartext-Password' WHERE attribute = 'User-Password' ;

ALTER TABLE `radgroupcheck` CHANGE `attribute` `attribute` VARCHAR( 64 ) NOT NULL default '' ;

ALTER TABLE `radgroupreply` CHANGE `attribute` `attribute` VARCHAR( 64 ) NOT NULL default '' ;

DROP TABLE `radippool` ;

ALTER TABLE `radpostauth` CHANGE `user` `username` VARCHAR( 64 ) NOT NULL default '' ;
ALTER TABLE `radpostauth` CHANGE `date` `authdate` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ;

ALTER TABLE `radreply` CHANGE `attribute` `attribute` VARCHAR( 64 ) NOT NULL default '' ;

CREATE TABLE `radusergroup` (
  `username` varchar(64) NOT NULL default '',
  `groupname` varchar(64) NOT NULL default '',
  `priority` int(11) NOT NULL default '1',
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `rm_actsrv` DROP `nasip` ;
ALTER TABLE `rm_actsrv` DROP `nasport` ;

DROP TABLE IF EXISTS `rm_allowednases`;
CREATE TABLE `rm_allowednases` (
  `username` varbinary(64) NOT NULL,
  `nasid` int(11) NOT NULL,
  KEY `srvid` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `rm_cards` CHANGE `downlimit` `downlimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_cards` CHANGE `uplimit` `uplimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_cards` CHANGE `comblimit` `comblimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_cards` CHANGE `timelimit` `uptimelimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_cards` CHANGE `expiretime` `expiretime` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_cards` CHANGE `expiretimeunit` `timebaseexp` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_cards` ADD `timebaseonline` TINYINT( 1 ) NOT NULL ;

ALTER TABLE `rm_changesrv` CHANGE `scheduledate` `scheduledate` DATETIME NOT NULL ;

ALTER TABLE `rm_ias` CHANGE `availdl` `downlimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_ias` CHANGE `availul` `uplimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_ias` CHANGE `availtotal` `comblimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_ias` CHANGE `availuptime` `uptimelimit` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_ias` CHANGE `timeamount` `expiretime` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_ias` CHANGE `timeunit` `timebaseonline` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_ias` ADD `timebaseexp` TINYINT( 1 ) NOT NULL AFTER `timebaseonline` ;
ALTER TABLE `rm_ias` CHANGE `validity` `expiration` DATE NOT NULL ;

ALTER TABLE `rm_invoices` CHANGE `hours` `time` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `service` `service` VARCHAR( 60 ) NOT NULL ;
ALTER TABLE `rm_invoices` DROP `taxpercent` ;
ALTER TABLE `rm_invoices` DROP `taxtype` ;
ALTER TABLE `rm_invoices` ADD `vatpercent` INT( 2 ) NOT NULL AFTER `tax` ;

ALTER TABLE `rm_managers` ADD `perm_allusers` TINYINT( 1 ) NOT NULL AFTER `perm_editinvoice` ;
UPDATE rm_managers SET perm_allusers = '1' WHERE managername = 'admin' ;

ALTER TABLE `rm_services` CHANGE `unitprice` `unitprice` DECIMAL( 25, 6 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `unitpriceadd` `unitpriceadd` DECIMAL( 25, 6 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `timebase` `timebaseexp` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `timebaseonline` TINYINT( 1 ) NOT NULL AFTER `timebaseexp` ;
ALTER TABLE `rm_services` CHANGE `timeunit` `timeunitexp` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `timeunitonline` INT( 11 ) NOT NULL AFTER `timeunitexp` ;
ALTER TABLE `rm_services` CHANGE `inittime` `inittimeexp` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `inittimeonline` INT( 11 ) NOT NULL AFTER `inittimeexp` ;
ALTER TABLE `rm_services` CHANGE `timeaddmode` `timeaddmodeexp` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `timeaddmodeonline` TINYINT( 1 ) NOT NULL AFTER `timeaddmodeexp` ;
ALTER TABLE `rm_services` DROP `taxpercent` ;
ALTER TABLE `rm_services` CHANGE `minamount` `minamount` INT( 20 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `unitpricetax` `unitpricetax` DECIMAL( 25, 6 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `unitpriceaddtax` `unitpriceaddtax` DECIMAL( 25, 6 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `nextsrvid` `nextsrvid` INT( 11 ) NOT NULL ;

ALTER TABLE `rm_settings` DROP `taxtypecash` ;
ALTER TABLE `rm_settings` DROP `taxtypefirm` ;
ALTER TABLE `rm_settings` CHANGE `taxpercentglobal` `vatpercent` DECIMAL( 4, 2 ) NOT NULL ;
ALTER TABLE `rm_settings` CHANGE `exchangeusd` `exchangeusd` DECIMAL( 20, 6 ) NOT NULL ;
ALTER TABLE `rm_settings` CHANGE `exchangegbp` `exchangegbp` DECIMAL( 20, 6 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `pm_authorizenetcc` TINYINT( 1 ) NOT NULL AFTER `pm_netcashcc` ;
ALTER TABLE `rm_settings` ADD `maclock` TINYINT( 1 ) NOT NULL ,
ADD `billingstart` tinyint(2) NOT NULL ,
ADD `renewday` tinyint(2) NOT NULL ,
ADD `changepswucp` tinyint(1) NOT NULL ,
ADD `selfreg_firstname` tinyint(1) NOT NULL ,
ADD `selfreg_lastname` tinyint(1) NOT NULL ,
ADD `selfreg_address` tinyint(1) NOT NULL ,
ADD `selfreg_city` tinyint(1) NOT NULL ,
ADD `selfreg_zip` tinyint(1) NOT NULL ,
ADD `selfreg_country` tinyint(1) NOT NULL ,
ADD `selfreg_state` tinyint(1) NOT NULL ,
ADD `selfreg_phone` tinyint(1) NOT NULL ,
ADD `selfreg_mobile` tinyint(1) NOT NULL ,
ADD `selfreg_email` tinyint(1) NOT NULL ,
ADD `selfreg_verify` tinyint(1) NOT NULL ;

ALTER TABLE `rm_users` ADD `verifycode` VARCHAR( 10 ) NOT NULL ,
ADD `verified` TINYINT( 1 ) NOT NULL ,
ADD `selfreg` TINYINT( 1 ) NOT NULL ,
ADD `verifyfails` TINYINT( 4 ) NOT NULL ;
ALTER TABLE `rm_users` DROP INDEX `profid` ,
ADD INDEX `srvid` ( `srvid` ) ;

DROP TABLE `usergroup` ;

INSERT INTO rm_allowednases( username, nasid ) 
SELECT rm_users.username, nas.id
FROM rm_users, nas ;

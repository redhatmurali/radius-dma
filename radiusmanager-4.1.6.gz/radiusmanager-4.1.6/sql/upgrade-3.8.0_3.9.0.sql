DELIMITER $$

DROP PROCEDURE IF EXISTS add_index $$
CREATE PROCEDURE add_index(in theTable varchar(128), in theIndexName varchar(128), in theIndexColumns varchar(128) )
BEGIN
 IF ( (SELECT COUNT(*) AS index_exists FROM information_schema.statistics WHERE TABLE_SCHEMA = DATABASE() and table_name =
       theTable AND index_name = theIndexName)  = 0) THEN
   SET @s = CONCAT('CREATE INDEX ' , theIndexName , ' ON ' , theTable, '(', theIndexColumns, ')');
   PREPARE stmt FROM @s;
   EXECUTE stmt;
 END IF;
END $$

ALTER TABLE `nas` CHANGE `_password` `starospassword` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `nas` CHANGE `_ciscobwmode` `ciscobwmode` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `nas` ADD `apiusername` VARCHAR( 32 ) NOT NULL ,
ADD `apipassword` VARCHAR( 32 ) NOT NULL ,
ADD `enableapi` TINYINT( 1 ) NOT NULL ;

ALTER TABLE `radacct` ADD `_dailynextsrvactive` TINYINT( 1 ) NULL ;
CALL add_index('radacct','_accttime','_accttime') ;

ALTER TABLE `rm_actsrv` ADD `dailynextsrvactive` TINYINT( 1 ) NOT NULL ;

CREATE TABLE `rm_allowedmanagers` (
  `srvid` int(11) NOT NULL,
  `managername` varchar(64) NOT NULL,
  KEY `srvid` (`srvid`),
  KEY `managername` (`managername`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO rm_allowedmanagers( srvid, managername ) 
SELECT rm_services.srvid, rm_managers.managername
FROM rm_services, rm_managers ;

ALTER TABLE `rm_cards` ADD INDEX ( `series` ) ;
ALTER TABLE `rm_cards` ADD INDEX ( `used` ) ;

ALTER TABLE `rm_changesrv` ADD INDEX ( `requestdate` ) ;
ALTER TABLE `rm_changesrv` ADD INDEX ( `scheduledate` ) ;

ALTER TABLE `rm_invoices` CHANGE `vatpercent` `vatpercent` DECIMAL( 4, 2 ) NOT NULL ;

ALTER TABLE `rm_managers` ADD `perm_edituserspriv` TINYINT( 1 ) NOT NULL AFTER `perm_editusers` ;
UPDATE `radius`.`rm_managers` SET `perm_edituserspriv` = '1' WHERE CONVERT( `rm_managers`.`managername` USING utf8 ) = 'admin' LIMIT 1 ;

ALTER TABLE `rm_radacct` DROP PRIMARY KEY ;
ALTER TABLE `rm_radacct` ADD INDEX ( `radacctid` ) ;

ALTER TABLE `rm_services` CHANGE `dlbursttreshold` `dlburstthreshold` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `ulbursttreshold` `ulburstthreshold` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `dailynextsrvid` INT NOT NULL AFTER `nextsrvid` ;
ALTER TABLE `rm_services` ADD `custattr` VARCHAR( 255 ) NOT NULL ;
UPDATE rm_services SET dailynextsrvid = -1 ;

ALTER TABLE `rm_settings` CHANGE `enchangesrv` `changesrv` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warndlpercent` INT( 3 ) NOT NULL AFTER `warndl` ;
ALTER TABLE `rm_settings` ADD `warnulpercent` INT( 3 ) NOT NULL AFTER `warnul` ;
ALTER TABLE `rm_settings` ADD `warncombpercent` INT( 3 ) NOT NULL AFTER `warncomb` ;
ALTER TABLE `rm_settings` ADD `warnuptimepercent` INT( 3 ) NOT NULL AFTER `warnuptime` ;
ALTER TABLE `rm_settings` ADD `warnmode` TINYINT( 1 ) NOT NULL AFTER `emailwarning` ;
ALTER TABLE `rm_settings` ADD `pm_2co` TINYINT( 1 ) NOT NULL AFTER `pm_dps` ;
ALTER TABLE `rm_settings` ADD `redeemucp` TINYINT( 1 ) NOT NULL AFTER `changepswucp` ;
ALTER TABLE `rm_settings` ADD `buycreditsucp` TINYINT( 1 ) NOT NULL AFTER `redeemucp` ;

RENAME TABLE `rm_specperiods` TO `rm_specperacnt` ;
ALTER TABLE `rm_specperacnt` CHANGE `specperid` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ;

CREATE TABLE `rm_specperbw` (
  `id` int(11) NOT NULL auto_increment,
  `srvid` int(11) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `dlrate` int(11) NOT NULL,
  `ulrate` int(11) NOT NULL,
  `dlburstlimit` int(11) NOT NULL,
  `ulburstlimit` int(11) NOT NULL,
  `dlburstthreshold` int(11) NOT NULL,
  `ulburstthreshold` int(11) NOT NULL,
  `dlbursttime` int(11) NOT NULL,
  `ulbursttime` int(11) NOT NULL,
  `enableburst` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `mon` tinyint(1) NOT NULL,
  `tue` tinyint(1) NOT NULL,
  `wed` tinyint(1) NOT NULL,
  `thu` tinyint(1) NOT NULL,
  `fri` tinyint(1) NOT NULL,
  `sat` tinyint(1) NOT NULL,
  `sun` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

ALTER TABLE `rm_users` ADD `custattr` VARCHAR( 255 ) NOT NULL AFTER `maccm` ;
ALTER TABLE `rm_users` ADD INDEX ( `owner` ) ;

DROP PROCEDURE IF EXISTS add_index ;

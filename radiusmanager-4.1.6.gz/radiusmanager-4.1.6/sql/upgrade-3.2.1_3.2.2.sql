ALTER TABLE `rm_users` CHANGE `username` `username` VARCHAR( 64 ) NOT NULL ;

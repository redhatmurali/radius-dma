# update table 'rm_managers'

ALTER TABLE `rm_managers` ADD `enablemanager` BOOL NOT NULL ;
UPDATE `rm_managers` SET `enablemanager` = '1' ;

# update table 'rm_services'

ALTER TABLE `rm_services` ADD `enableburst` BOOL NOT NULL ,
ADD `dlburstlimit` INT( 11 ) NOT NULL ,
ADD `ulburstlimit` INT( 11 ) NOT NULL ,
ADD `dlbursttreshold` INT( 11 ) NOT NULL ,
ADD `ulbursttreshold` INT( 11 ) NOT NULL ,
ADD `dlbursttime` INT( 11 ) NOT NULL ,
ADD `ulbursttime` INT( 11 ) NOT NULL ,
ADD `enableservice` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `dlquota` BIGINT NOT NULL ;
ALTER TABLE `rm_services` ADD `ulquota` BIGINT NOT NULL ;
ALTER TABLE `rm_services` ADD `timequota` BIGINT NOT NULL ;
UPDATE `rm_services` SET `enableservice` = '1';

INSERT INTO `rm_services` (`srvid`, `srvname`, `downrate`, `uprate`, `limitdl`, `limitul`, `limitexpiration`, `limituptime`, `poolname`, `unitprice`, `unitpriceadd`, `timebase`, `timeunit`, `trafficunit`, `srvtype`, `timeaddmode`, `trafficaddmode`, `timeadd`, `trafficadd`, `monthly`, `enaddcredits`, `taxpercent`, `minamount`, `resetcounters`, `pricecalcdownload`, `pricecalcupload`, `pricecalcuptime`, `unitpricetax`, `unitpriceaddtax`, `enableburst`, `dlburstlimit`, `ulburstlimit`, `dlbursttreshold`, `ulbursttreshold`, `dlbursttime`, `ulbursttime`, `enableservice`, `dlquota`, `ulquota`, `timequota`) VALUES
(0, 'Default service', 786432, 393216, 0, 0, 0, 0, '', '0.17', '0.00', 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, '18.00', 1, 0, 1, 0, 0, '0.03', '0.00', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);

# update table 'rm_users'

ALTER TABLE `rm_users` ADD `maccm` VARCHAR( 17 ) NOT NULL ,
ADD `maccpe` VARCHAR( 17 ) NOT NULL ;

# update table 'rm_cards'

ALTER TABLE `rm_cards` ADD `active` BOOL NOT NULL ,
ADD `expiredays` INT NOT NULL ;
UPDATE rm_cards SET active = 1 ;

# update table 'rm_settings'

ALTER TABLE `rm_settings` ADD `lang` VARCHAR( 20 ) NOT NULL ;
UPDATE `rm_settings` SET `lang` = 'English' ;

# update table 'rm_invoices'

ALTER TABLE `rm_invoices` ADD `balance` DECIMAL( 20, 2 ) NOT NULL ;
